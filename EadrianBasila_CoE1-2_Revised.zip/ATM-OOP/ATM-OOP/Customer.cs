﻿

using System;
using System.Collections.Generic;
using System.Text;

namespace ATM_OOP
{
    class Customer
    {
        public string Name { get; set; }
        public string First_Name { get; set; }
        public string Middle_Name { get; set; }
        public string Last_Name { get; set; }
        public string Passcode { get; set; }
        public int Balance { get; set; }
    }
}